use pinyin::ToPinyin;
use std::{io::Write, path::PathBuf};

fn main() {
    let arg = std::env::args().collect::<Vec<String>>();
    if arg.len() < 2 {
        println!("Usage:\n.\"{}\" <FullFilePath> ...", arg[0]);
        return;
    }

    for i in arg.iter().skip(1) {
        calc(arg[0].clone(), i.clone());
    }
}

fn calc(exe_path: String, file_path: String) {
    let path = {
        let temp = PathBuf::from(
            file_path
                .replace("\r\n", "\n")
                .trim_matches(&['"', '\'', '\\', '/', '\t', '\n', '\r', '`']),
        );
        if !temp.is_file() {
            panic!();
        };
        if (!temp.is_absolute()) && (!temp.exists()) {
            PathBuf::from(exe_path).join(temp)
        } else {
            temp
        }
    };
    println!("{}", path.display());
    if path.as_os_str().is_empty() {
        panic!();
    }

    let ext = path.extension().unwrap().to_str().unwrap();
    let output_path = PathBuf::from(format!(
        "{}_out.{}",
        path.to_str()
            .unwrap()
            .trim_end_matches(&format!(".{}", ext)),
        ext
    ));

    let mut out_file = std::fs::File::create(&output_path).unwrap();
    let file = std::fs::read_to_string(path).unwrap();
    let content = file.lines().collect::<Vec<&str>>();

    let mut collection: std::collections::HashMap<String, String> =
        std::collections::HashMap::new();

    for line in content {
        if line.is_empty() {
            continue;
        }
        let sentence_py = line
            .to_pinyin()
            .map(|f| match f {
                Some(f) => f.with_tone_num_end(),
                None => {
                    println!("{}", line);
                    ""
                }
            })
            .collect::<Vec<&str>>()
            .join("");
        collection.insert(sentence_py, line.to_string());
    }

    let mut vec_collection = collection.into_iter().collect::<Vec<(String, String)>>();
    vec_collection.sort_unstable_by(|(a, _), (b, _)| a.cmp(b));

    for (_, i) in vec_collection {
        out_file.write(format!("{}\n", i).as_bytes()).unwrap();
    }
    out_file.flush().unwrap();

    println!("{}\nFinished.\n", output_path.display());
}
